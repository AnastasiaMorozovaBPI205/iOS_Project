//
//  LayerColorModel.swift
//  TestingPackage
//
//  Created by Anastasia on 09.03.2022.
//

import UIKit

public struct LayerColorsModel {
    var colorTop: CGColor
    var colorMiddle: CGColor
    var colorBottom: CGColor
    
    public init(top: CGColor, mid: CGColor, bottom: CGColor) {
        colorTop = top
        colorMiddle = mid
        colorBottom = bottom
    }
}
