//
//  TaskModel.swift
//  TestingPackage
//
//  Created by Anastasia on 12.03.2022.
//

import UIKit

public struct TaskModel {
    var text: String
    var answer: String
    
    public init(text: String, answer: String) {
        self.text = text
        self.answer = answer
    }
}
