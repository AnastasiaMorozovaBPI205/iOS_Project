//
//  TaskView.swift
//  TestingPackage
//
//  Created by Anastasia on 08.03.2022.
//

import UIKit

public class TaskView: UIView {
    var taskViewTextColor: UIColor = .black
    var taskViewButtonTextColor: UIColor = .black
    var taskViewLayerColorModel: LayerColorsModel = LayerColorsModel(
        top: UIColor.HEXToUIColor(color: "2EC4E6").cgColor,
        mid: UIColor.HEXToUIColor(color: "2EC4E6").cgColor,
        bottom: UIColor.HEXToUIColor(color: "2EC4E6").cgColor
    )
    public var loadCheckViewDelegate: LoadCheckViewDelegate?
    var tasks: [TaskModel] = []
    var currentTask: TaskModel = TaskModel(text: "", answer: "")
    
    var taskText: UILabel = {
        let textField = UILabel(frame: CGRect(x: 0, y: 0, width: 280, height: 35))
        textField.backgroundColor = .white
        
        textField.setHeight(to: 35)
        textField.setWidth(to: 280)
        
        textField.layer.cornerRadius = textField.layer.frame.height / 2
        textField.layer.masksToBounds = true
        
        textField.lineBreakMode = .byWordWrapping
        textField.numberOfLines = 3
        
        textField.textAlignment = .center
        
        return textField
    }()
    
    public var userAnswer: UITextView = {
        let textField = UITextView(frame: CGRect(x: 0, y: 0, width: 280, height: 35))
        textField.backgroundColor = .white
        
        textField.setHeight(to: 35)
        textField.setWidth(to: 280)
        
        textField.layer.cornerRadius = textField.frame.height / 2
        textField.layer.masksToBounds = true
        
        textField.font = .systemFont(ofSize: 16)
        textField.textContainerInset = UIEdgeInsets(
            top: 10,
            left: 10,
            bottom: 10,
            right: 10
        )
        
        return textField
    }()
    
    var checkButton: UIButton = {
        let checkButton = UIButton(frame: CGRect(x: 0, y: 0, width: 80, height: 32))
        checkButton.backgroundColor = .white
        checkButton.setTitle("Check", for: .normal)
        checkButton.layer.cornerRadius = checkButton.bounds.height / 2
        checkButton.clipsToBounds = true
        
        checkButton.addTarget(
            self,
            action: #selector(checkAnswer),
            for: .touchUpInside
        )
        
        return checkButton
    }()
    
    var generateTaskButton: UIButton = {
        let generateTaskButton = UIButton(frame: CGRect(x: 0, y: 0, width: 180, height: 33))
        generateTaskButton.backgroundColor = .white
        generateTaskButton.setTitle("Generate new task", for: .normal)
        generateTaskButton.layer.cornerRadius = generateTaskButton.frame.height / 2
        
        generateTaskButton.addTarget(
            self,
            action: #selector(generateTaskButtonTapped),
            for: .touchUpInside
        )
        
        return generateTaskButton
    }()
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    @available(*, unavailable)
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    public func setupTaskView(
        tasks: [TaskModel],
        textColor: UIColor,
        buttonTextColor: UIColor,
        layerColorModel: LayerColorsModel
    ) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            layerColorModel.colorTop,
            layerColorModel.colorMiddle,
            layerColorModel.colorBottom
        ]
        gradientLayer.locations = [0.0, 0.5,  1.0]
        gradientLayer.frame = CGRect(
            x: 0,
            y: 0,
            width: self.frame.size.height,
            height: self.frame.size.height
        )
        
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        
        layer.insertSublayer(gradientLayer, at:0)
        
        self.tasks = tasks
        taskViewTextColor = textColor
        taskViewButtonTextColor = buttonTextColor
        taskViewLayerColorModel = layerColorModel
        
        currentTask = tasks[Int.random(in: 0..<tasks.count)]
        
        setupTaskText(taskText: currentTask.text, textColor: textColor)
        setupUserAnswer(textColor: textColor)
        setupButtons(buttonTitleColor: buttonTextColor)
    }
    
    private func setupTaskText(taskText: String, textColor: UIColor) {
        self.taskText.text = taskText
        self.taskText.textColor = textColor
        self.taskText.setWidth(to: Double(self.frame.width) - 40)
        self.addSubview(self.taskText)
        self.taskText.pinLeft(
            to: self,
            Double(frame.width / 2 - self.taskText.frame.width / 2)
        )
        self.taskText.pinTop(to: self, 40)
    }
    
    private func setupUserAnswer(textColor: UIColor) {
        userAnswer.setWidth(to: Double(self.frame.width) - 40)
        userAnswer.textColor = textColor
        self.addSubview(userAnswer)
        self.userAnswer.pinLeft(
            to: self,
            Double(frame.width / 2 - userAnswer.frame.width / 2)
        )
        self.userAnswer.pinTop(to: self.taskText, Double(self.taskText.frame.height) + 20)
    }
    
    private func setupButtons(buttonTitleColor: UIColor) {
        checkButton.setTitleColor(buttonTitleColor, for: .normal)
        self.addSubview(checkButton)
        checkButton.pinLeft(to: self, 20)
        checkButton.pinTop(to: userAnswer, Double(userAnswer.frame.height) + 20)
        checkButton.setWidth(to: 80)
        
        generateTaskButton.setTitleColor(buttonTitleColor, for: .normal)
        self.addSubview(generateTaskButton)
        generateTaskButton.pinRight(to: self, 20)
        generateTaskButton.pinTop(to: userAnswer, Double(userAnswer.frame.height) + 20)
        generateTaskButton.setWidth(to: 180)
    }
    
    @objc
    private func checkAnswer(_ sender: UIButton) {
        let checkViewController = CheckViewController()
        checkViewController.setupCheckView(
            rightAnswer: currentTask.answer,
            wasUserAnswerRight: userAnswer.text == currentTask.answer,
            textColor: taskViewTextColor,
            buttonTextColor: taskViewButtonTextColor,
            layerColorModel: taskViewLayerColorModel
        )
        
        self.loadCheckViewDelegate?.loadCheckView(checkViewController: checkViewController)
    }
    
    @objc
    private func generateTaskButtonTapped(_ sender: UIButton) {
        currentTask = tasks[Int.random(in: 0..<tasks.count)]
        taskText.text = currentTask.text
        userAnswer.text = ""
    }
}
