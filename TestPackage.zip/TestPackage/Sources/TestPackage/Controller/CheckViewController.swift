//
//  CheckViewController.swift
//  TestingPackage
//
//  Created by Anastasia on 11.03.2022.
//

import UIKit

public protocol LoadCheckViewDelegate {
    func loadCheckView(checkViewController: CheckViewController)
}

public class CheckViewController: UIViewController {
    let imageView = UIImageView(frame: CGRect(x: 0, y: 0, width: 50, height: 50))
    
    var answerText: UILabel = {
        let textField = UILabel(frame: CGRect(x: 0, y: 0, width: 280, height: 150))
        textField.backgroundColor = .white
        
        textField.setHeight(to: 150)
        textField.setWidth(to: 280)
        
        textField.layer.cornerRadius = textField.layer.frame.height / 4
        textField.layer.masksToBounds = true
        
        textField.lineBreakMode = .byWordWrapping
        textField.numberOfLines = 3
        
        textField.textAlignment = .center
        
        return textField
    }()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @objc
    private func closeScreen() {
        dismiss(animated: true, completion: nil)
        navigationController?.popViewController(animated: true)
    }
    
    private func setupCloseButton() {
        if #available(iOS 13.0, *) {
            let button = UIButton(type: .close)
            
            view.addSubview(button)
            button.translatesAutoresizingMaskIntoConstraints = false
            
            button.pinRight(to: view.trailingAnchor, 10)
            button.pinTop(to: view.topAnchor, 10)
            
            button.setHeight(to: 30)
            button.widthAnchor.constraint(equalTo:button.heightAnchor).isActive = true
            
            button.addTarget(self, action: #selector(closeScreen),for: .touchUpInside)
        } else {
            // Fallback on earlier versions
        }
    }
    
    func setupCheckView(rightAnswer: String,
                        wasUserAnswerRight: Bool,
                        textColor: UIColor,
                        buttonTextColor: UIColor,
                        layerColorModel: LayerColorsModel
    ) {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [
            layerColorModel.colorTop,
            layerColorModel.colorMiddle,
            layerColorModel.colorBottom
        ]
        gradientLayer.locations = [0.0, 0.5,  1.0]
        gradientLayer.frame = CGRect(
            x: 0,
            y: 0,
            width: view.frame.size.height,
            height: view.frame.size.height
        )
        
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        
        view.layer.insertSublayer(gradientLayer, at:0)
        
        setupImages(wasUserAnswerRight: wasUserAnswerRight)
        setupAnswerText(
            rightAnswer: rightAnswer,
            wasUserAnswerRight: wasUserAnswerRight,
            textColor: textColor
        )
        setupCloseButton()
    }
    
    private func setupImages(wasUserAnswerRight: Bool) {
        if (wasUserAnswerRight) {
            imageView.image = UIImage(named:"right")
        } else {
            imageView.image = UIImage(named:"wrong")
        }
        
        view.addSubview(imageView)
        imageView.pinLeft(
            to: view,
            Double(view.frame.width / 2 - imageView.frame.width / 2)
        )
        imageView.pinTop(to: view, 40)
    }
    
    private func setupAnswerText(rightAnswer: String,
                                 wasUserAnswerRight: Bool,
                                 textColor: UIColor
    ) {
        if (wasUserAnswerRight) {
            answerText.text = "Your answer was correct!\u{1F496}\nThe right answer is:\n" + rightAnswer
        } else {
            answerText.text = "Your answer was incorrect!\nThe right answer is:\n" + rightAnswer
        }
        
        answerText.textColor = textColor
        
        answerText.setWidth(to: Double(view.frame.width) - 40)
        view.addSubview(answerText)
        answerText.pinLeft(
            to: view,
            Double(view.frame.width / 2 - answerText.frame.width / 2)
        )
        answerText.pinTop(to: imageView, Double(imageView.frame.height) + 20)
    }
}


