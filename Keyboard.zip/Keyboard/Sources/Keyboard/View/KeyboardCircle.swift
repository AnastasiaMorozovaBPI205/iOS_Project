//
//  Keyboard.swift
//  CourseProject
//
//  Created by Anastasia on 01.01.2022.
//

import UIKit

public class KeyboardCircle: UIView {
    var buttons: [UIButton] = []
    var circleView = UIView()
    
    public weak var typingDelegate: KeyboardTypingDelegate?
    public weak var symbolDelegate: KeyboardSymbolsDelegate?
    public weak var shiftDelegate: KeyboardShiftDelegate?
    
    public init(frame: CGRect, buttonNumber: UInt32, circleModel: Circle) {
        super.init(frame: frame)
        
        setupCircleView(circleModel: circleModel)
        setupCenterCircleButtons(buttonNumber: buttonNumber, circleModel: circleModel)
        
        circleView.center = center
    }
    
    public init(
        frame: CGRect,
        firstLetter: Character,
        letterNumber: UInt32,
        circleModel: Circle,
        isAlphabetCircle: Bool
    ) {
        super.init(frame: frame)
        
        setupCircleView(circleModel: circleModel)
        setupSymbolButtons(
            firstLetter: firstLetter,
            letterNumber: letterNumber,
            circleModel: circleModel,
            isAlphabetCircle: isAlphabetCircle
        )
        
        circleView.center = center
    }
    
    @available(*, unavailable)
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    @available(*, unavailable)
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    private func setupCircleView(circleModel: Circle) {
        let diameter = Float(frame.height)
        
        circleView = UIView(
            frame: CGRect(
                x: 0,
                y: 0,
                width: CGFloat(diameter),
                height: CGFloat(diameter)
            )
        )
        
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [circleModel.colorTop, circleModel.colorBottom]
        gradientLayer.locations = [0.0, 1.0]
        gradientLayer.frame = CGRect(
            x: 0,
            y: 0,
            width: circleView.frame.size.height,
            height: circleView.frame.size.height
        )
        
        layer.insertSublayer(gradientLayer, at:0)
        
        layer.cornerRadius = circleView.frame.size.width/2
        clipsToBounds = true
    }
    
    private func setupButtonShadow(button: UIButton) {
        button.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        button.layer.shadowOffset = CGSize(width: 0.0, height: 1.5)
        button.layer.shadowOpacity = 0.7
        button.layer.shadowRadius = 0.0
        button.layer.masksToBounds = false
    }
    
    private func setupButtonPosition(button: UIButton,
                                     degrees: CGFloat,
                                     radius: CGFloat,
                                     item: UInt32) {
        let horizontalOffset = radius * cos(CGFloat(item) * degrees * .pi / 180)
        let verticalOffset = radius * sin(CGFloat(item) * degrees * .pi / 180)
        
        button.translatesAutoresizingMaskIntoConstraints = false
        button.centerXAnchor.constraint(
            equalTo: centerXAnchor,
            constant: horizontalOffset
        ).isActive = true
        button.centerYAnchor.constraint(
            equalTo: centerYAnchor,
            constant: verticalOffset
        ).isActive = true
    }
    
    private func setupSymbolButtons(firstLetter: Character,
                                    letterNumber: UInt32,
                                    circleModel: Circle,
                                    isAlphabetCircle: Bool) {
        let firstLetterScalar = firstLetter.unicodeScalars
        let firstLetterCode = firstLetterScalar[firstLetterScalar.startIndex].value
        var letters: [String] = []
        
        var number: UInt32 = 0
        var nextLetter: String
        while letters.count < letterNumber {
            nextLetter = String(Character(UnicodeScalar(firstLetterCode + number) ?? "a"))
            
            if (!isAlphabetCircle && (nextLetter == "A" || nextLetter == "a")) {
                number += 26
                nextLetter = String(Character(UnicodeScalar(firstLetterCode + number) ?? "a"))
            }
            
            letters.append(nextLetter)
            number += 1
        }
        
        var button: UIButton
        for item in 0..<letterNumber {
            button = UIButton()
            
            button.setTitle(letters[Int(item)], for: .normal)
            button.setTitleColor(circleModel.buttonTitleColor, for: .normal)
            button.backgroundColor = .white
            
            button.setWidth(to: 30)
            button.setHeight(to: 35)
            button.layer.cornerRadius = 15
            button.clipsToBounds = true
            
            button.addTarget(
                self,
                action: #selector(symbolButtonWasPressed),
                for: .touchUpInside
            )
            
            setupButtonShadow(button: button)
            
            addSubview(button)
            setupButtonPosition(
                button: button,
                degrees: circleModel.degrees,
                radius: circleModel.radius,
                item: item
            )
            buttons.append(button)
        }
    }
    
    private func setupCenterCircleButtons(buttonNumber: UInt32, circleModel: Circle) {
        var button: UIButton
        for item in 0...buttonNumber {
            button = UIButton()
            
            button.setTitleColor(circleModel.buttonTitleColor, for: .normal)
            button.backgroundColor = .white
            button.titleLabel?.font = .systemFont(ofSize: 12)
            
            button.layer.cornerRadius = 18
            button.clipsToBounds = true
            
            setupButtonShadow(button: button)
            
            addSubview(button)
            setupButtonPosition(
                button: button,
                degrees: circleModel.degrees,
                radius: circleModel.radius,
                item: item
            )
            buttons.append(button)
        }
        
        setupImageButtons()
        setupSymbolButton()
        setupReturnButton()
        setupSpaceButton()
    }
    
    private func setupImageButtons() {
        buttons[0].setTitle("del", for: .normal)
        //buttons[0].setImage(UIImage(named: "erase_button"), for: .normal)
        buttons[0].addTarget(
            self,
            action: #selector(eraseButtonWasPressed),
            for: .touchUpInside
        )
        buttons[0].setWidth(to: 50)
        buttons[0].setHeight(to: 30)
        buttons[0].layer.cornerRadius = 15
        
        buttons[1].setTitle("shift", for: .normal)
        //buttons[1].setImage(UIImage(named: "shift_off_button"), for: .normal)
        buttons[1].addTarget(
            self,
            action: #selector(shiftButtonWasPressed),
            for: .touchUpInside
        )
        buttons[1].setWidth(to: 50)
        buttons[1].setHeight(to: 30)
        buttons[1].layer.cornerRadius = 15
        
        buttons[2].setTitle("globe", for: .normal)
        //buttons[2].setImage(UIImage(named: "globe_button"), for: .normal)
        buttons[2].setWidth(to: 50)
        buttons[2].setHeight(to: 30)
        buttons[2].layer.cornerRadius = 15
    }
    
    private func setupSymbolButton() {
        buttons[3].setTitle(".?123", for: .normal)
        buttons[3].setWidth(to: 35)
        buttons[3].setHeight(to: 35)
        buttons[3].layer.cornerRadius = 18
        
        buttons[3].addTarget(
            self,
            action: #selector(symbolsButtonWasPressed),
            for: .touchUpInside
        )
    }
    
    private func setupReturnButton() {
        buttons[4].setTitle("return", for: .normal)
        buttons[4].setWidth(to: 50)
        buttons[4].setHeight(to: 30)
        buttons[4].layer.cornerRadius = 15
        
        buttons[4].addTarget(
            self,
            action: #selector(returnButtonWasPressed),
            for: .touchUpInside
        )
    }
    
    private func setupSpaceButton() {
        buttons[5].setTitle("space", for: .normal)
        buttons[5].setWidth(to: 50)
        buttons[5].setHeight(to: 30)
        buttons[5].layer.cornerRadius = 15
        
        buttons[5].addTarget(
            self,
            action: #selector(spaceButtonWasPressed),
            for: .touchUpInside
        )
    }
    
    @objc
    private func eraseButtonWasPressed(_ sender: UIButton) {
        self.typingDelegate?.eraseKeyWasTapped()
    }
    
    @objc
    private func symbolsButtonWasPressed(_ sender: UIButton) {
        if (sender.titleLabel?.text == ".?123") {
            sender.setTitle("ABC", for: .normal)
        } else {
            sender.setTitle(".?123", for: .normal)
        }
        
        self.symbolDelegate?.changeSymbolsKeyWasTapped()
    }
    
    @objc
    private func shiftButtonWasPressed(_ sender: UIButton) {
        self.shiftDelegate?.shiftKeyWasTapped()
    }
    
    @objc
    private func returnButtonWasPressed(_ sender: UIButton) {
        self.typingDelegate?.returnKeyWasTapped()
    }
    
    @objc
    private func spaceButtonWasPressed(_ sender: UIButton) {
        self.typingDelegate?.symbolKeyWasTapped(character: " ")
    }
    
    @objc
    func symbolButtonWasPressed(_ sender: UIButton) {
        guard let titleLabelText = sender.titleLabel?.text else {
            return
        }
        
        self.typingDelegate?.symbolKeyWasTapped(character: titleLabelText)
    }
    
    public override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let view = super.hitTest(point, with: event)
        return view == self ? nil : view
    }
}
