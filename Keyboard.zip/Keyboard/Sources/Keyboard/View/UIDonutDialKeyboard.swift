//
//  UIDonutDialKeyboard.swift
//  CourseProject
//
//  Created by Anastasia on 12.01.2022.
//

import UIKit

public protocol KeyboardShiftDelegate: AnyObject {
    func shiftKeyWasTapped()
}

public protocol KeyboardTypingDelegate: AnyObject {
    func symbolKeyWasTapped(character: String)
    func returnKeyWasTapped()
    func eraseKeyWasTapped()
}

public protocol KeyboardSymbolsDelegate: AnyObject {
    func changeSymbolsKeyWasTapped()
}

public class UIDonutDialKeyboard: UIView {
    public var alphabetCircles: [KeyboardCircle] = []
    public var symbolsCircles: [KeyboardCircle] = []
    public var isRotating = false
    public var canKeystrokeByRotation = false
    var layersNumber = 1
    var lettersNumbers: [UInt32] = []
    var symbolsNumbers: [UInt32] = []
    var alphabetCircleOn: Bool = true
    
    public init(
        frame: CGRect,
        layersNumber: Int,
        letterNumbers: [UInt32],
        layerColors: [LayerColorsModel],
        buttonTitleColor: UIColor
    ) {
        super.init(frame: frame)
        
        setupKeyboard(
            layersNumber: layersNumber,
            letterNumbers: letterNumbers,
            layerColors: layerColors,
            buttonTitleColor: buttonTitleColor,
            symbolsNumbers: [26, 15]
        )
    }
    
    @available(*, unavailable)
    public override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    @available(*, unavailable)
    public required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    private func setupCircles(layerColors: [LayerColorsModel],
                              buttonTitleColor: UIColor,
                              isAlphabetCircle: Bool) {
        var circle: KeyboardCircle
        var lastLetter = isAlphabetCircle ? "a" : "!"
        let degrees = 13.8
        
        for i in 0..<layersNumber-1 {
            let letterNumber = isAlphabetCircle ? lettersNumbers[i] : symbolsNumbers[i]
            
            circle = KeyboardCircle(
                frame: CGRect(
                    x: 0,
                    y: 0,
                    width: frame.width - CGFloat(100*i),
                    height: frame.width - CGFloat(100*i)
                ),
                firstLetter: Character(lastLetter),
                letterNumber: letterNumber,
                circleModel: Circle(degrees: CGFloat(degrees + Double(i*10)),
                                    radius: CGFloat(frame.width / (2.3 + CGFloat(i))),
                                    colorTop: layerColors[i].colorTop,
                                    colorBottom: layerColors[i].colorBottom,
                                    buttonTitleColor: buttonTitleColor),
                isAlphabetCircle: isAlphabetCircle
            )
            
            if (isAlphabetCircle) {
                addSubview(circle)
                circle.center = center
                alphabetCircles.append(circle)
            } else {
                symbolsCircles.append(circle)
            }
            
            lastLetter = String(UnicodeScalar(lastLetter.unicodeScalars[lastLetter.unicodeScalars.startIndex].value + letterNumber) ?? "a")
        }
    }
    
    private func setupCenterCircle(layerColors: [LayerColorsModel],
                                   buttonTitleColor: UIColor) {
        let circle = KeyboardCircle(
            frame:  CGRect(
                x: 0,
                y: 0,
                width: frame.width - CGFloat(200),
                height: frame.width - CGFloat(200)
            ),
            buttonNumber: 5,
            circleModel: Circle(degrees: CGFloat(50),
                                radius: CGFloat(frame.width / 6),
                                colorTop: layerColors[layersNumber-1].colorTop,
                                colorBottom: layerColors[layersNumber-1].colorBottom,
                                buttonTitleColor: buttonTitleColor)
        )
        
        addSubview(circle)
        circle.center = center
        alphabetCircles.append(circle)
        symbolsCircles.append(circle)
    }
    
    private func setupKeyboard(layersNumber: Int,
                               letterNumbers: [UInt32],
                               layerColors: [LayerColorsModel],
                               buttonTitleColor: UIColor,
                               symbolsNumbers: [UInt32]) {
        self.layersNumber = layersNumber
        self.lettersNumbers = letterNumbers
        self.symbolsNumbers = symbolsNumbers
        
        setupCircles(layerColors: layerColors,
                     buttonTitleColor: buttonTitleColor,
                     isAlphabetCircle: true)
        setupCircles(layerColors: layerColors,
                     buttonTitleColor: buttonTitleColor,
                     isAlphabetCircle: false)
        setupCenterCircle(layerColors: layerColors, buttonTitleColor: buttonTitleColor)
        
        alphabetCircles.forEach{ circle in
            circle.shiftDelegate = self
            circle.symbolDelegate = self
        }
    }
    
    private func rotateCircle(rotatingCircle: KeyboardCircle, touch: UITouch) {
        let rotationAngle = atan2(
            rotatingCircle.center.y - touch.location(in: self).y,
            rotatingCircle.center.x - touch.location(in: self).x
        )
        
        rotatingCircle.transform = CGAffineTransform(rotationAngle: rotationAngle)
        
        rotatingCircle.buttons.forEach { button in
            button.transform = CGAffineTransform(rotationAngle: -rotationAngle)
        }
    }
    
    public override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        
        if (isRotating) {
            if (alphabetCircleOn) {
                rotateCircles(touch: touch, circles: alphabetCircles)
            } else {
                rotateCircles(touch: touch, circles: symbolsCircles)
            }
        }
    }
    
    private func rotateCircles(touch: UITouch, circles: [KeyboardCircle]) {
        guard let lastCircle = circles.last else {
            return
        }
        
        let area = pow(touch.location(in: self).y - lastCircle.center.y, 2) + pow(touch.location(in: self).x - lastCircle.center.x, 2)
        
        for i in stride(from: circles.count-1, through: 0, by: -1) {
            if area <= pow(circles[i].circleView.frame.height / 2, 2) {
                rotateCircle(rotatingCircle: circles[i], touch: touch)
                break
            }
        }
    }
    
    private func rotateCirclesBack(circles: [KeyboardCircle]) {
        circles.forEach { circle in
            UIView.animate(withDuration: 2) {
                circle.transform = .identity
                
                circle.buttons.forEach { button in
                    button.transform = .identity
                }
            }
        }
    }
    
    public override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if isRotating {
            if (alphabetCircleOn) {
                rotateCirclesBack(circles: alphabetCircles)
            } else {
                rotateCirclesBack(circles: symbolsCircles)
            }
        }
    }
}

extension UIDonutDialKeyboard: KeyboardShiftDelegate {
    public func shiftKeyWasTapped() {
        if (!alphabetCircleOn) {
            return
        }
        
        let isLowercase = Character(
            alphabetCircles[0].buttons[0].titleLabel?.text ?? "a"
        ).isLowercase
        
        for i in 0..<layersNumber-1 {
            for j in 0..<lettersNumbers[i] {
                if (isLowercase) {
                    alphabetCircles[i].buttons[Int(j)].setTitle(
                        alphabetCircles[i].buttons[Int(j)].currentTitle?.uppercased(),
                        for: .normal
                    )
                } else {
                    alphabetCircles[i].buttons[Int(j)].setTitle(
                        alphabetCircles[i].buttons[Int(j)].currentTitle?.lowercased(),
                        for: .normal
                    )
                }
            }
        }
    }
}

extension UIDonutDialKeyboard: KeyboardSymbolsDelegate {
    public func changeSymbolsKeyWasTapped() {
        if (alphabetCircleOn)  {
            alphabetCircleOn = false
            changeCircles(currentCircles: alphabetCircles, newCircles: symbolsCircles)
        } else {
            alphabetCircleOn = true
            changeCircles(currentCircles: symbolsCircles, newCircles: alphabetCircles)
        }
    }
    
    private func changeCircles(currentCircles: [KeyboardCircle], newCircles: [KeyboardCircle]) {
        for circle in currentCircles as [UIView] {
            circle.removeFromSuperview()
        }
        
        for circle in newCircles {
            addSubview(circle)
            circle.center = center
        }
    }
}
