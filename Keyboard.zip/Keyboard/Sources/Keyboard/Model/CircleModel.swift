//
//  CircleModel.swift
//  CourseProject
//
//  Created by Anastasia on 07.03.2022.
//

import UIKit

public struct Circle {
    var degrees: CGFloat
    var radius: CGFloat
    var colorTop: CGColor
    var colorBottom: CGColor
    var buttonTitleColor: UIColor
    
    public init(
        degrees: CGFloat,
        radius: CGFloat,
        colorTop: CGColor,
        colorBottom: CGColor,
        buttonTitleColor: UIColor
    ) {
        self.degrees = degrees
        self.radius = radius
        self.colorTop = colorTop
        self.colorBottom = colorBottom
        self.buttonTitleColor = buttonTitleColor
    }
}
