//
//  LayerColorsModel.swift
//  CourseProject
//
//  Created by Anastasia on 06.03.2022.
//

import UIKit

public struct LayerColorsModel {
    var colorTop: CGColor
    var colorBottom: CGColor
    
    public init(colorTop: CGColor, colorBottom: CGColor) {
        self.colorTop = colorTop
        self.colorBottom = colorBottom
    }
}
